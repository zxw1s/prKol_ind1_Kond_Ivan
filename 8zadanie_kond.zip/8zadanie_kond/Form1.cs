using System.Reflection.Metadata.Ecma335;
using System.IO;
namespace _8zadanie_kond
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int popo(string formula)
        {
            Stack<int> stack = new Stack<int>();
            string[] tokens = formula.Split(new char[] { '(', ')', ',', '|' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var token in tokens.Reverse())
            {
                if (token == "M")
                {
                    int max = stack.Pop();
                    int min = stack.Pop();
                    stack.Push(Math.Max(max, min));
                }
                else if (token == "m")
                {
                    int min = stack.Pop();
                    int max = stack.Pop();
                    stack.Push(Math.Min(min, max));
                }
                else
                {
                    stack.Push(int.Parse(token));
                }
            }

            return stack.Pop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string p = textBox1.Text;
            if (File.Exists(p))
            {
                StreamReader sr = File.OpenText(p);
                while (!sr.EndOfStream)
                {
                    string inputFormula = sr.ReadLine();
                    int result = popo(inputFormula);
                    listBox1.Items.Add(result.ToString());
                }
            }
            else
                MessageBox.Show("����� �� ����������");
        }
    }
}